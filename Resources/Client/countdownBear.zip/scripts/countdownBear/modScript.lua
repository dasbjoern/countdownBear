load("countdownBear")
setExtensionUnloadMode("countdownBear", "manual")
